function onAppReady() {
if( navigator.splashscreen && navigator.splashscreen.hide ) { 
navigator.splashscreen.hide() ;
initData();
$('#loader').css("display","block");

}
document.addEventListener("backbutton", onBackKeyDown, false);
}


document.addEventListener("app.Ready", onAppReady, false) ;
//Geolocation for devices
function GetLocation(){
navigator.geolocation.getCurrentPosition(onSuccess, onLocError);
}
function onSuccess(position) {
var mylat = position.coords.latitude;
var mylng = position.coords.longitude;
var msa = mylat+","+mylng;
GetAddressz(msa);
}

 function onLocError(error) {
cordova.plugins.diagnostic.switchToLocationSettings();
navigator.notification.alert("Please enable your location settings","","Warning!");
}
function Notify(msg,tit){
 myApp.alert(msg, tit, function () {
        myApp.closePanel();
    });
}
function GetAddresszS(data,status){
//alert("resp is "+data);
if(data !==""){
if (window.DOMParser){
    parser=new DOMParser();
    xmlDoc=parser.parseFromString(data,"text/xml");
}
else{
    xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
    xmlDoc.async=false;
    xmlDoc.loadXML(data);
  }
var maxml = xmlDoc.getElementsByTagName("long_name")[2].childNodes[0].nodeValue;
var maxmli = xmlDoc.getElementsByTagName("long_name")[4].childNodes[0].nodeValue;
var lc11 = xmlDoc.getElementsByTagName("short_name")[11].childNodes[0].nodeValue; 
//alert("locations are..."+maxml +" and "+maxmli);
$('#myLocation').html("<center>You are in <img src='img/location.png' width='20px' height='20px'>"+maxml +","+maxmli+"</center>");
StoreTemp("myare",maxml);
StoreTemp("mycit",maxmli);
CheckConnection(1);
}
}
function GetAddresszF(data,status){
Notify("Please check your network","Network Error");
$('#loader').css("display","none");
}
 function GetAddressz(msa){
     // myApp.showIndicator("Loading");
var key = "AIzaSyBVBGTNqrYts689RCC2L72Xwj7HhgxgUP8";
var funnel = "https://mobilepushserver.com";
$.ajax({
type: 'GET',
url: funnel+'/services/maps.php',
data: {key:key,latlng:msa},
success: GetAddresszS,
error : GetAddresszF,
cache:false,
async:true,
dataType: 'html'
}); 
		
}

function MapAddress(){
var loc = $('#manuva').val(); 
//alert("i got "+loc);
GetAddressz(loc);
}

function StoreTemp(keys,vals){
sessionStorage.setItem(keys,vals);
}

function GetStoreTemp(key){
var locData = sessionStorage.getItem(key);
return locData;
}

function onBackKeyDown() {
myApp.closeModal();
myApp.closePanel();
var lstlstPage = GetStoreTemp("oldPage");
var lstPage = GetStoreTemp("currentPage");
if(lstlstPage===null ){
ExitApp();
}
else{
Navigate(lstlstPage,lstPage);
}
    }

function ExitApp(){
 myApp.confirm('Are you sure?','Exit App', 
function () {
    navigator.app.exitApp();
      },
      function () {
        myApp.alert('You are still here','Manuva');
     myApp.closeModal(); 
      }
    );
}

function loopInsertion(){
//var iLen = 10;
//for(var i=0;i<iLen;i++){
var plId = GetStoreTemp("placeId");
//alert("new plid is "+plId);
if(plId===null){
StoreTemp("defLabel","Place A");
StoreTemp("placeId","0");
StoreTemp("defArea","Rivonia Boulevard");
StoreTemp("defCity","Sandton");
StoreTemp("defRating","5");
insertQuery();

}

if(plId==='0'){
//alert("i===1");
StoreTemp("defLabel","Place B");
StoreTemp("placeId","1");
StoreTemp("defArea","Wilgeheuwel");
StoreTemp("defCity","Roodepoort");
StoreTemp("defRating","2.4");
insertQuery();

}
if(plId==='1'){
//alert("i===2");
StoreTemp("defLabel","Place C");
StoreTemp("placeId","2");
StoreTemp("defArea","Senaoane");
StoreTemp("defCity","Soweto");
StoreTemp("defRating","2");
insertQuery();

}
if(plId==='2'){
StoreTemp("defLabel","Place D");
StoreTemp("placeId","3");
StoreTemp("defArea","Mpumalanga");
StoreTemp("defCity","East Vaal District Council");
StoreTemp("defRating","4");
insertQuery();
}
if(plId==='3'){
StoreTemp("defLabel","Place E");
StoreTemp("placeId","4");
StoreTemp("defArea","Uthungulu DC");
StoreTemp("defCity","KwaZulu Natal");
StoreTemp("defRating","3");
insertQuery();
}
if(plId==='4'){
StoreTemp("defLabel","Place F");
StoreTemp("placeId","5");
StoreTemp("defArea","Uthukela DC");
StoreTemp("defCity","KwaZulu Natal");
StoreTemp("defRating","1");
insertQuery();

}
if(plId==='5'){
StoreTemp("defLabel","Place G");
StoreTemp("placeId","6");
StoreTemp("defArea","Xhariep");
StoreTemp("defCity","Free State");
StoreTemp("defRating","2");
insertQuery();
}
if(plId==='6'){
//alert("i===7");
StoreTemp("defLabel","Place H");
StoreTemp("placeId","7");
StoreTemp("defArea","Cape Town");
StoreTemp("defCity","Western Cape");
StoreTemp("defRating","4");
insertQuery();
}
if(plId==='7'){
StoreTemp("defLabel","Place I");
StoreTemp("placeId","8");
StoreTemp("defArea","Table Mountain(Nature Reserve)");
StoreTemp("defCity","Cape Town");
StoreTemp("defRating","3");
insertQuery();
}
if(plId==='8'){
//alert("i===9");
StoreTemp("defLabel","Place J");
StoreTemp("placeId","9");
StoreTemp("defArea","Cape Farms");
StoreTemp("defCity","Cape Town");
StoreTemp("defRating","4");
insertQuery();
}


}

function CheckConnection(id){
//alert("checkcon is "+id);
 var networkState = navigator.connection.type;
  var states = {};
    states[Connection.UNKNOWN]  = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI]     = 'WiFi connection';
    states[Connection.CELL_2G]  = 'Cell 2G connection';
    states[Connection.CELL_3G]  = 'Cell 3G connection';
    states[Connection.CELL_4G]  = 'Cell 4G connection';
    states[Connection.CELL]     = 'Cell generic connection';
    states[Connection.NONE]     = 'No network connection';  
   var contype =  states[networkState];
    if(contype==='No network connection'){
       navigator.notification.alert("Please check your connection.","","You are offline");
    }
    else{
    if(id===1){
    GoogDist();
    } 
}
}

function GoogDistS(data,status){
var placesData = JSON.parse(data);
var rows = placesData.rows[0].elements[0].distance.text;
$dis1 = rows;
//alert("googdist result is "+$dis1);
//alert("before km is "+$dis1);
//var mystring = "crt/r2002_2";
var fmData = $dis1.replace('km','');
$diskm = fmData.replace(',','');
$diskm = parseInt($diskm);
//alert("after km is "+$diskm);
$dism = ($diskm*1000);//meters
//alert("in meters is "+$dism);
var mike = parseInt($diskm);
//alert("val is "+mike);
$dismil = (mike*621);//miles
$dismi = ($dismil/1000);//miles
//alert("in miles is "+$dismi);
StoreTemp("dist1",$diskm);
StoreTemp("dist2",$dism);
StoreTemp("dist3",$dismi);
updateRecord();
var id = GetStoreTemp("placeId");
}

function GoogDistF(data,status){
Notify(status,"Google Distance API error ");  
$('#loader').css("display","none");
}

function GoogDist(){   
//get dest1 and dest2 from db
FindPlaces();
}

function Logout(){
 myApp.confirm('Are you sure?','Logout Confirmation', 
function () {  
      },
      function () {
     myApp.alert('You are still here','Keep manuvaring!');
      }
    );
}
function Navigate(page,old){
$('#'+old).css("display","none");
$('#'+page).css("display","block");
StoreTemp("oldPage",old);
StoreTemp("currentPage",page);
myApp.closePanel();    
}
function Abo() {
  Navigate('aboview','mainpage');   
}

function ModeSwitch(){
 var uscm = document.getElementById("modes").selectedIndex;
var uatym = document.getElementById("modes")[uscm].value;

if(uatym==='Choose a mode'){
NewPop("Please choose a filter type","Incomplete Task");    
}
else{
if(uatym ==='dist1'){
 db.transaction(function (tx) {
tx.executeSql(selectDistA, [], function (tx, result) {
var dataset = result.rows;
var datLen = dataset.length;

if(datLen ===0){
Notify("Your device does not support SQLITE","Message");
}
else{
$("#geoplaces").html(''); 
for (var i = 0, item = null; i < datLen; i++) {
item = dataset.item(i);
var where = item['labeli'];
var distkmi = item['distA'];
var rating = item['rating'];
var km = "km";
var geoContent = "<li class='item-content'><div class='item-inner'><div class='item-title'>" +where+ "   " +distkmi+km+"</div><div class='item-after'><span class='badge'>" +rating+"</span></div></div></li>";

$("#geoplaces").append(geoContent);    
}
   
$('#loader').css("display","none");
}
});
 });
}
if(uatym ==='dist2'){
db.transaction(function (tx) {
tx.executeSql(selectDistB, [], function (tx, result) {
var dataset = result.rows;
var datLen = dataset.length;

if(datLen ===0){
Notify("Your device does not support SQLITE","Message");
}
else{
$("#geoplaces").html(''); 
for (var i = 0, item = null; i < datLen; i++) {
item = dataset.item(i);
var where = item['labeli'];
var distkmi = item['distB'];
var rating = item['rating'];
var meters = "meters";
var geoContent = "<li class='item-content'><div class='item-inner'><div class='item-title'>"+where+"    " +distkmi+meters+"</div><div class='item-after'><span class='badge'>" +rating+"</span></div></div></li>";
$("#geoplaces").append(geoContent);    
}
   
$('#loader').css("display","none");
}
});
 });
}
if(uatym ==='dist3'){
db.transaction(function (tx) {
tx.executeSql(selectDistB, [], function (tx, result) {
var dataset = result.rows;
var datLen = dataset.length;

if(datLen ===0){
Notify("Your device does not support SQLITE","Message");
}
else{
$("#geoplaces").html(''); 
for (var i = 0, item = null; i < datLen; i++) {
item = dataset.item(i);
var where = item['labeli'];
var distkmi = item['distC'];
var rating = item['rating'];
var mile = "miles";
var geoContent = "<li class='item-content'><div class='item-inner'><div class='item-title'>"+where+"  " +distkmi+mile+"</div><div class='item-after'><span class='badge'>" +rating+"</span></div></div></li>";
$("#geoplaces").append(geoContent);    
}
   
$('#loader').css("display","none");
}
});
 });
}
if(uatym ==='rating'){
db.transaction(function (tx) {
tx.executeSql(selectRating, [], function (tx, result) {
var dataset = result.rows;
var datLen = dataset.length;

if(datLen ===0){
Notify("Your device does not support SQLITE","Message");
}
else{
$("#geoplaces").html(''); 
for (var i = 0, item = null; i < datLen; i++) {
item = dataset.item(i);
var where = item['labeli'];
var distkmi = item['distA'];
var rating = item['rating'];
var km = "km";
var geoContent = "<li class='item-content'><div class='item-inner'><div class='item-title'>"+where+"  " +distkmi+km+"</div><div class='item-after'><span class='badge'>" +rating+"</span></div></div></li>";
$("#geoplaces").append(geoContent);    
}
   
$('#loader').css("display","none");
}
});
 });
}
//TimedPop("All your service requests will be done in " +uatym+ "mode");
//PermStorage("com_mode",uatym);
//var com_modeI = PullPermReq("com_mode");
//alert("Here is the comm mode "+com_modeI);
}   
}