
var createPlaces = "CREATE TABLE IF NOT EXISTS Geo (id INTEGER PRIMARY KEY AUTOINCREMENT, labeli TEXT ,city TEXT, rating FLOAT, distA INT, distB INT,distC FLOAT)";

var selectAllPlaces = "SELECT city FROM Geo WHERE labeli = ?";

var selectRating = "SELECT * FROM Geo ORDER BY rating DESC";

var selectRating2 = "SELECT * FROM Geo ORDER BY rating ASC";

var selectDistA = "SELECT * FROM Geo ORDER BY distA ASC";

var selectDistA2 = "SELECT * FROM Geo ORDER BY distA DESC";

var selectDistB = "SELECT * FROM Geo ORDER BY distB ASC";

var selectDistB2 = "SELECT * FROM Geo ORDER BY distB DESC";

var selectDistC = "SELECT * FROM Geo ORDER BY distC ASC";

var selectDistC2 = "SELECT * FROM Geo ORDER BY distC DESC";
 
var insertStatement = "INSERT INTO Geo (labeli,city,rating,distA,distB,distC) VALUES (?,?,?,?,?,?)";
//var insertStatement = "INSERT INTO Places (labeli,city,rating,dist1,dist2,dist3) VALUES (?,?,?,?,?,?)";

var updateDist = "UPDATE Geo SET distA = ?, distB = ?, distC = ? WHERE labeli = ?";

var dropStatement = "DROP TABLE Geo";


var geoDB = "ManuvaMichael"; 
 var db = openDatabase(geoDB, "1.0", "ManuvaGroup", 200000); 
var dataset; 
var DataType;
function initData(){
try {
if (!window.openDatabase){
}
else {
DropTbl();
createTable(); 
}
}
catch (e) {
if (e == 2) {
console.log("Invalid database version.");
} 
else {
console.log("Unknown error " + e + ".");
}
return;
}

}

function DropTbl(){
db.transaction(function (tx) { tx.executeSql(dropStatement, [], dropConf, onErrorDrop);});   
}
function dropConf(){
//alert("dropped");
}
function onErrorDrop(tx,error){
//alert("dropTable is "+error.message);
}
function ClearTempStorage(key){
sessionStorage.removeItem(key);
}
function ClearAllTempStorage(){
sessionStorage.clear();
}
function createTable() {
ClearTempStorage("placeId");
ClearAllTempStorage();
db.transaction(function (tx) { tx.executeSql(createPlaces, [], showNotes, onErrorTab); });
}

function showNotes(){
//alert("table was created");
 loopInsertion();
}   
function onErrorTab(tx, error){
//alert("table crea err..."+error.message);
} 
function onError(tx, error){
alert(error.message);
} 
function onErrorUp(tx, error){
alert("update error"+error.message);
} 
function onErrorIns(tx, error){
alert("insertion issue "+error.message);
} 
function onShowError(tx,error){
myApp.alert(error.message,"Create chat error");
}


function FindPlaces(){
var id = GetStoreTemp("placeId");
var myLabel = GetStoreTemp("defLabel");
//alert("place is "+myLabel);
 db.transaction(function (tx) {
tx.executeSql(selectAllPlaces, [myLabel], function (tx, result) {
var dataset = result.rows;
//alert("dataset is "+dataset);
var dLen = dataset.length;
//alert("findplace length is "+dLen);
if(dLen ===0){
Notify("Empty Database","Message");
}
else{
for (var i = 0, item = null; i < dLen; i++) {
item = dataset.item(i);
var mtitle = item['city'];
//alert("retrieved place is "+mtitle);
StoreTemp("destination",mtitle);

//var there1 = "Rivonia Boulevard";//;GetStoreTemp("dest1");
//var there2 = "Sandton";//GetStoreTemp("dest2");
CalcDistance();
}
}
});
 });

}

function CalcDistance(){
//alert("in calc distance");
var here1 = GetStoreTemp("myare");
var here2 = GetStoreTemp("mycit");
var places = GetStoreTemp("destination");
var key = "AIzaSyBVBGTNqrYts689RCC2L72Xwj7HhgxgUP8";
var funnel = "https://maps.googleapis.com/maps/api/distancematrix/json";
var here = here1+","+here2;
//var here = here1+"|"+here2;
var there = places;//there1+","+there2;
//alert("here is "+here+"there is "+there);
$.ajax({
type: 'GET',
url: funnel,
data: {key:key,origins:here,destinations:there},
success: GoogDistS,
error : GoogDistF,
cache:false,
async:true,
dataType: 'html'
}); 
}

function insertQuery(){
var myLabel = GetStoreTemp("defLabel");
var tit = GetStoreTemp("defArea");
var con = GetStoreTemp("defCity");
var plas = tit+","+con;
//alert("theplace");
var ratin = GetStoreTemp("defRating");
var dis1 = "1";
var dis2 = "2";
var dis3 = "3";
db.transaction(function (tx) { tx.executeSql(insertStatement, [myLabel,plas,ratin,dis1,dis2,dis3], doneInsert, onErrorIns); });
//db.transaction(function (tx) { tx.executeSql(insertStatement, [myLabel,plas,ratin,dis1,dis2,dis3], doneInsert, onErrorIns); });
}

function doneInsert(){  
var plid = GetStoreTemp("placeId");
//alert("placeid is currently "+plid);
GetLocation();
    ///FindPlaces

}

function updateRecord(){
var d1 = GetStoreTemp("dist1");
var d2 = GetStoreTemp("dist2");
var d3 = GetStoreTemp("dist3");

var myLabel = GetStoreTemp("defLabel");
//alert("in update label is "+myLabel);
db.transaction(function (tx) { tx.executeSql(updateDist, [d1, d2, d3, myLabel], updateConf, onErrorUp); });

}
function updateConf(){
var id = GetStoreTemp("placeId");
//alert("in updateconf id is "+id);
if(id==='0'){
//alert("inside zero "+id);    

loopInsertion();
}
if(id==='1'){
//StoreTemp("placeId","2");
loopInsertion();
}
if(id==='2'){
//StoreTemp("placeId","3");
loopInsertion();
}
if(id==='3'){
//StoreTemp("placeId","4");
loopInsertion();
}
if(id==='4'){
//StoreTemp("placeId","5");
loopInsertion();
}
if(id==='5'){
//StoreTemp("placeId","6");
loopInsertion();
}
if(id==='6'){
//StoreTemp("placeId","7");
loopInsertion();
}
if(id==='7'){
//StoreTemp("placeId","8");
loopInsertion();
}
if(id==='8'){
//StoreTemp("placeId","9");
loopInsertion();
}
var id = GetStoreTemp("placeId");
if(id==='9'){
//Show listview
//
//alert("id on 226 is "+9);
 db.transaction(function (tx) {
tx.executeSql(selectDistA, [], function (tx, result) {
var dataset = result.rows;
var datLen = dataset.length;

if(datLen ===0){
Notify("Your device does not support SQLITE","Message");
}
else{
$("#geoplaces").html(''); 
for (var i = 0, item = null; i < datLen; i++) {
item = dataset.item(i);
var where = item['labeli'];
var distkmi = item['distA'];
var rating = item['rating'];
var km = "km";
var geoContent = "<li class='item-content'><div class='item-inner'><div class='item-title'>" +where+ "   " +distkmi+km+"</div><div class='item-after'><span class='badge'>" +rating+"</span></div></div></li>";
$("#geoplaces").append(geoContent);    
}
   
$('#loader').css("display","none");
}
});
 });
}
 }
